<?php
# bassad 2.2 2012-11-18
# 
# Author: Michael Stathers <mike@stathers.net>
#
# Displays all videos within a directory for in browser viewing.
# I find the VLC browser plugin to work the best for viewing video

###### Set your options here #######
$dir = "files";
$title = "Mike's Home File Server";
$bgcolor = "#97A6A1";
####################################


?>
<!-- Generating html header tags -->
<html>
	<head>
		<title><?echo $title?></title>
	</head>
	<body style="font-family:'Arial';background-color:<?echo $bgcolor?>">
		<h1 style="text-align:center"><?echo $title?></h1>
		
		<!--  Search form: stores as $query variable -->
		<form style="position:absolute;top:10px;right:5px" method="post" action="index.php"><input type="text" name="search" value="Search" onFocus="this.value=''"></form>
		<?$query = preg_quote($_POST["search"]); ?>

		<div style="margin-left:auto;margin-right:auto;width:86%;position:relative;background-color:#FFFFFF;-moz-border-radius:10px;-webkit-border-radius:10px;border-radius:8px;padding:15px;">

<?

#searching through directory for video files
$it = new RecursiveDirectoryIterator($dir);
foreach(new RecursiveIteratorIterator($it) as $file) {
	if (preg_match("/(.*$query.*)(\.avi$|\.mkv$|\.mp4$|\.m4v$)/i",$file)){
		#get filename from path
		$name = basename($file);
		#convert special characters to html entities
		$file = htmlspecialchars($file);
		$file = str_replace(" ","%20",$file);
		#print url link
		echo "<a href=$file>$name</a><br />";
	}
}
?>

<!-- closing out the html tags -->
		</div>
	</body>
</html>


<!--
   Copyright 2012 Michael Stathers

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

-->
